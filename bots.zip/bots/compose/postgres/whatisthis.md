Placeholder for a dockerfile to incorporate PostgreSQL as docker container for testing.
