Placeholder for a dockerfile to incorporate MySQL as docker container for testing.
