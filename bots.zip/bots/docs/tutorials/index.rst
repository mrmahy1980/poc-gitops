Tutorials
=========

General EDI and Bots specific implementation tutorials. 

.. toctree::
    :maxdepth: 2

    edi-basics
    odoo-integration
