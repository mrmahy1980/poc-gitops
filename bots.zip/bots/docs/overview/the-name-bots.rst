The name ``Bots``
=================

EDI is about cooperation in the supply chain (collaboration, tying together, etc). That is true, but on the other hand it is also a clash of cultures. In Dutch **bots** is like **crash**

``bots`` is also the nickname my grandfather-in-law used for my girlfriend. it was not clear where that name came from, probably that was how she pronouced her name (betsy) when she learned to talk.

In Dutch ``bots`` is singular.

but...its just a name.

kind regards, henk-jan
