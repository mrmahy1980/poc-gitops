Overview
========

Purpose of the chapter of this wiki is to give some global overview for bots open source edi translator.

An overview of features is on `sourceforge <http://bots.sourceforge.net/en/about_features.shtml>`_.

**Table of Contents:**

.. toctree::
   :maxdepth: 2

   the-name-bots
   techincal-overview
   directories-files
   configuration-files
   glossary 
