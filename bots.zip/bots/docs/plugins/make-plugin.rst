Make a Plugin
=============

It is very easy to generate a plugin from your own configuration:

#. Go to ``bots-monitor->Systasks->Make plugin``.
#. Select what your want in the plugin (defaults are for a configuration plugin).
#. Click button ``Make plugin``.
#. Give filename/path to save the plugin.
