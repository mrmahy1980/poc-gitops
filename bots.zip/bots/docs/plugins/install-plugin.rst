Install a Plugin
================

* First download the plugin from the `bots sourceforge site <http://sourceforge.net/projects/bots/files/plugins/>`_ to your file system.
* Go to ``bots-monitor-Systasks->Read plugin``.
* Select the plugin from your system.
* After selecting choose ``Read``.

Bots will now report that is has read the plugin.

.. note::
    In order to run the routes in a plugin you first have to activate the routes.

.. note::
    grammars for edifact and x12 are NOT plugins, and can not be installed.
