How to Get Grammars
===================

* **edifact and x12**: There are grammars for all edifact and x12 messages on the `bots sourceforge site <http://sourceforge.net/projects/bots/files/grammars/>`_.
* **xml**: use command line tool ``bots-xml2botsgrammar.py`` to generate a grammar from an xml file. Help for this utility script is provided using parameter ``-h``
* **csv, fixed etc**: use examples in plugins, expand these
