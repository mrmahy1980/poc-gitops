EDI Partners
============

Plugin ``demo_partnerdependent`` at the `bots sourceforge site <http://sourceforge.net/projects/bots/files/plugins/>`_ demonstrates working with edi partners.

.. rubric::
    Index

.. toctree::
    :maxdepth: 2

    partner-lookup
    partner-groups
    partner-syntax
    partner-translation
    organize-partner-translation
