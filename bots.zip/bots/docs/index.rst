.. bots documentation master file, created by
   sphinx-quickstart on Thu Sep 17 18:17:11 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

-----------------
Table of Contents
-----------------

.. toctree::
   :maxdepth: 2
    
   readme
   introduction
   installation
   get-bots-running
   quick-start-guide/index
   guide-for-botsmonitor/index
   overview/index
   configuration/index
   deployment/index
   advanced-deployment/index
   plugins/index
   tutorials/index
   debugging
   troubleshooting
   change-migrate/index
   new-to-python
   external-reference
   useful-tools
   documentation
