#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bots import botsupdatedb

if __name__ == '__main__':
    botsupdatedb.start()
