#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bots import xml2botsgrammar

if __name__ == '__main__':
    xml2botsgrammar.start()
