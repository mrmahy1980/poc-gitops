#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bots import job2queue

if __name__ == '__main__':
    job2queue.start()
