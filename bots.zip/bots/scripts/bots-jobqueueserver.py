#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bots import jobqueueserver

if __name__ == '__main__':
    jobqueueserver.start()
