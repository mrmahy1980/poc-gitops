#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bots import dirmonitor

if __name__ == '__main__':
    dirmonitor.start()
