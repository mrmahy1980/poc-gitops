#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bots import plugoutindex

if __name__ == '__main__':
    plugoutindex.start()
