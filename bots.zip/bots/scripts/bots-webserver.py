#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bots import webserver

if __name__ == '__main__':
    webserver.start()
