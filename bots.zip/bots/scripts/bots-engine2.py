#!/usr/bin/env python
# -*- coding: utf-8 -*-

from bots import engine2

if __name__ == '__main__':
    engine2.start()
